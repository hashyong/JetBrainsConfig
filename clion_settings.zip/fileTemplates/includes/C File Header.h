#if ($HEADER_COMMENTS)
//
// -*- coding: utf-8-unix; -*-
//  Copyright (c) $YEAR Tencent, Inc.
//     All rights reserved.
//
// Author: yongbohe@tencent.com
// Date:   ${DATE} ${TIME}
// File:   ${FILE_NAME}
// Desc:   
//
#end

